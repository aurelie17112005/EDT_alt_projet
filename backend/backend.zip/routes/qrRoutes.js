const express = require('express');
const router = express.Router();
const { generateQRCode } = require('../controllers/qrController');

// Route pour générer le QR Code
router.post('/generate', generateQRCode);

module.exports = router;
