'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('Attendances', 'mode', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'QR',
    });
    await queryInterface.addColumn('Attendances', 'qrCodeId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: {
        model: 'QRCodes',
        key: 'id',
      },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL',
    });
  },

  down: async (queryInterface) => {
    await queryInterface.removeColumn('Attendances', 'mode');
    await queryInterface.removeColumn('Attendances', 'qrCodeId');
  }
};
