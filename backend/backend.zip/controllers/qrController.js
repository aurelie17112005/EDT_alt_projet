const jwt = require('jsonwebtoken');
const qrcode = require('qrcode');
const { Session } = require('../models/Session');

const SECRET_KEY = process.env.SECRET_KEY;
const QR_CODE_EXPIRATION = 5 * 60; // 5 minutes en secondes

// Fonction pour générer un QR Code pour une séance
exports.generateQRCode = async (req, res) => {
    const { sessionId } = req.body; // ID de la séance

    if (!sessionId) {
        return res.status(400).json({ message: 'Session ID is required' });
    }

    // Vérifier si la séance existe
    const session = await Session.findByPk(sessionId);
    if (!session) {
        return res.status(404).json({ message: 'Session not found' });
    }

    // Créer un jeton JWT pour le QR Code
    const token = jwt.sign({ sessionId }, SECRET_KEY, { expiresIn: QR_CODE_EXPIRATION });

    // Générer le QR Code à partir du jeton JWT
    qrcode.toDataURL(token, (err, url) => {
        if (err) {
            return res.status(500).json({ message: 'Error generating QR Code' });
        }

        res.json({ qrCodeUrl: url });
    });
};
const { Attendance } = require('../models/Attendance');

// Fonction pour scanner un QR Code et enregistrer la présence
exports.scanQRCode = async (req, res) => {
    const { token, studentId } = req.body; // Le jeton scanné et ID de l'étudiant

    if (!token || !studentId) {
        return res.status(400).json({ message: 'Token and student ID are required' });
    }

    // Vérifier le jeton JWT
    jwt.verify(token, SECRET_KEY, async (err, decoded) => {
        if (err) {
            return res.status(400).json({ message: 'QR Code has expired or is invalid' });
        }

        const { sessionId } = decoded;

        // Enregistrer la présence de l'étudiant
        try {
            const attendance = await Attendance.create({
                sessionId,
                studentId,
                timestamp: new Date(),
                mode: 'QR'
            });

            res.json({ message: 'Presence recorded successfully', attendance });
        } catch (error) {
            res.status(500).json({ message: 'Error recording attendance', error });
        }
    });
};
