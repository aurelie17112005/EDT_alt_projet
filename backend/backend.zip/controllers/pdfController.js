const PDFDocument = require('pdfkit');
const Session = require('../models/Session');
const Attendance = require('../models/Attendance');
const User = require('../models/User');

exports.generatePdf = async (req, res) => {
  try {
    const sessionId = req.params.sessionId;

    const session = await Session.findByPk(sessionId, {
      include: [{ model: User, as: 'teacher' }]
    });

    if (!session) {
      return res.status(404).json({ message: 'Séance non trouvée' });
    }

    const attendances = await Attendance.findAll({
      where: { SessionId: sessionId },
      include: [{ model: User, as: 'student' }]
    });

    // Créer le PDF
    const doc = new PDFDocument();
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=emargement_session_${sessionId}.pdf`);
    doc.pipe(res);

    doc.fontSize(16).text(`Fiche d’émargement - ${session.subject}`, { underline: true });
    doc.moveDown();
    doc.fontSize(12).text(`Salle : ${session.room}`);
    doc.text(`Heure : ${new Date(session.startTime).toLocaleString()} - ${new Date(session.endTime).toLocaleString()}`);
    doc.text(`Enseignant : ${session.teacher.firstName} ${session.teacher.lastName}`);
    doc.moveDown();

    doc.fontSize(14).text('Présences :');
    doc.moveDown(0.5);

    attendances.forEach((att, i) => {
      const student = att.student;
      doc.fontSize(12).text(`${i + 1}. ${student.firstName} ${student.lastName} - ${student.email}`);
    });

    doc.end();
  } catch (err) {
    console.error('Erreur génération PDF :', err);
    res.status(500).json({ message: 'Erreur serveur PDF' });
  }
};
