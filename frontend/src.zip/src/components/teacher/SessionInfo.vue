<template>
  <v-card outlined>
    <v-card-title class="secondary white--text">
      Informations séance
    </v-card-title>
    <v-card-text>
      <v-simple-table>
        <template v-slot:default>
          <tbody>
            <tr>
              <td><strong>Matière</strong></td>
              <td>{{ session.subject }}</td>
            </tr>
            <tr>
              <td><strong>Salle</strong></td>
              <td>{{ session.room }}</td>
            </tr>
            <tr>
              <td><strong>Horaire</strong></td>
              <td>{{ formatTime(session.start_time) }} - {{ formatTime(session.end_time) }}</td>
            </tr>
          </tbody>
        </template>
      </v-simple-table>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  name: 'SessionInfo',
  props: {
    session: {
      type: Object,
      required: true
    }
  },
  methods: {
    formatTime(dateString) {
      return new Date(dateString).toLocaleTimeString('fr-FR', { 
        hour: '2-digit', 
        minute: '2-digit' 
      })
    }
  }
}
</script>