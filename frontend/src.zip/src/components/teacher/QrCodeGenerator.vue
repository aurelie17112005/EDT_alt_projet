<template>
  <div class="qr-generator">
    <v-btn @click="generateQr" color="primary">Générer QR Code</v-btn>
    <div v-if="qrData" class="mt-4">
      
      <p class="mt-2">Valide jusqu'à: {{ expiryTime }}</p>
    </div>
  </div>
</template>

<script>

export default {
  name: 'QrCodeGenerator',
  components: { QrCode },
  data: () => ({
    qrData: '',
    expiryTime: ''
  }),
  methods: {
    async generateQr() {
      try {
        const response = await this.$api.post('/sessions/generate')
        this.qrData = response.data.token
        this.expiryTime = new Date(response.data.expiry).toLocaleString()
      } catch (error) {
        console.error('Error generating QR:', error)
      }
    }
  }
}
</script>