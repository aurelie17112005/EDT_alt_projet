<template>
  <v-container>
    <session-info />
    <v-row class="mt-4">
      <v-col cols="12" md="6">
        <qr-code-generator />
      </v-col>
      <v-col cols="12" md="6">
        <attendance-list />
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import QrCodeGenerator from '@/components/teacher/QrCodeGenerator'
import AttendanceList from '@/components/teacher/AttendanceList'
import SessionInfo from '@/components/teacher/SessionInfo'

export default {
  name: 'SessionView',
  components: {
    QrCodeGenerator,
    AttendanceList,
    SessionInfo
  }
}
</script>